def dividirNumeros(a,b):
    print("los elementos", a, b)
    return a/b

